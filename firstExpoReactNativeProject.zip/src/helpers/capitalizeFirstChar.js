function capitalizeFirstChar(str) {
  return str[0].toUpperCase() + str.slice(1)
}

export default capitalizeFirstChar
